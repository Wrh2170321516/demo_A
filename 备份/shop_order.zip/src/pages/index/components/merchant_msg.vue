<template>
  <view class="User_info">
    商家信息
    <view> 电话:888 9999 6666</view>
    <view> 作者邮箱：python2607@163.com</view>
  </view>
</template>

<script>
export default {};
</script>

<style lang="scss">
.User_info {
  height: 300rpx;
  background-color: $uni-color-success;
  margin-bottom: 15rpx;
}
</style>